# LikeSunny Header Animation Plugin

WordPress 插件，為 LikeSunny 網站添加載入時的 header 動畫效果。

## 功能特色

- 網站載入時立即隱藏原有 header
- 顯示動畫 logo，進行縮小和消失動畫
- 動畫完成後顯示原有 header
- 支援滾動觸發或自動觸發（3秒後）
- 包含錯誤處理和超時保護
- 響應式設計，支援行動裝置

## 安裝方式

1. 將整個 `likesunny-header-animation` 資料夾上傳到 WordPress 的 `/wp-content/plugins/` 目錄
2. 在 WordPress 管理後台的「插件」頁面啟用「LikeSunny Header Animation」
3. 插件會自動在前端頁面載入時運作

## 檔案結構

```
likesunny-header-animation/
├── likesunny-header-animation.php  # 主插件檔案
├── assets/
│   ├── css/
│   │   └── header-animation.css    # 動畫樣式
│   ├── js/
│   │   └── header-animation.js     # 動畫邏輯
│   └── images/
│       ├── logo-large.svg          # 大 logo
│       └── logo-small.svg          # 小 logo（目前未使用）
└── README.md                       # 說明文件
```

## 動畫流程

1. **頁面載入時**：立即隱藏原有 header（opacity: 0）
2. **第一階段**：顯示大 logo，等待滾動或3秒自動觸發
3. **第二階段**：logo 開始縮小動畫（2秒）
4. **第三階段**：3秒後 header 淡出消失（0.6秒）
5. **完成**：顯示原有網站 header

## 技術細節

- 使用 `position: fixed` 確保動畫 header 在最上層
- 使用 `z-index: 999999` 避免被其他元素遮蓋
- 針對 Divi 主題的 `.et-l--header` 選擇器進行隱藏
- 包含錯誤處理，8秒後強制顯示原有 header
- 使用 `requestAnimationFrame` 優化滾動效能

## 自訂設定

若需修改動畫參數，可編輯以下檔案：

- `assets/css/header-animation.css`：調整樣式和動畫時間
- `assets/js/header-animation.js`：修改動畫邏輯和觸發條件
- `likesunny-header-animation.php`：更改 logo 路徑或新增設定選項

## 相容性

- WordPress 5.0+
- 測試於 Divi 主題
- 支援現代瀏覽器（Chrome, Firefox, Safari, Edge）
- 響應式設計，支援行動裝置

## 版本歷史

### v1.0.0
- 初始版本
- 基本動畫功能
- 支援滾動和自動觸發
- 包含錯誤處理機制